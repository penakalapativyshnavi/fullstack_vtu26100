<?php
$conn = mysqli_connect("localhost", "root", "", "login_system",3307);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$message = "";

if(isset($_POST['login'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];

    if($username != "" && $password != "") {

        $query = "SELECT * FROM users 
                  WHERE username='$username' 
                  AND password='$password'";

        $result = mysqli_query($conn, $query);

        if(mysqli_num_rows($result) > 0) {

            $user = mysqli_fetch_assoc($result);
            $message = "Login Successful! Welcome " . $user['username'];

        } else {
            $message = "Invalid Username or Password!";
        }

    } else {
        $message = "All fields are required!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Login System</title>

<style>
body {
    font-family: Arial;
    background: #f4f4f4;
}

.container {
    width: 350px;
    margin: 100px auto;
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px #ccc;
}

h2 {
    text-align: center;
}

input {
    width: 100%;
    padding: 8px;
    margin: 10px 0;
}

button {
    width: 100%;
    padding: 10px;
    background: green;
    color: white;
    border: none;
    cursor: pointer;
}

.message {
    text-align: center;
    margin-top: 10px;
    font-weight: bold;
    color: red;
}
</style>

<script>
function validateForm() {

    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;

    if(username === "" || password === "") {
        document.getElementById("jsError").innerHTML = 
        "Both fields are required!";
        return false;
    }

    return true;
}
</script>

</head>

<body>

<div class="container">
<h2>Login</h2>

<form method="POST" onsubmit="return validateForm()">

<input type="text" 
       name="username" 
       id="username" 
       placeholder="Enter Username">

<input type="password" 
       name="password" 
       id="password" 
       placeholder="Enter Password">

<button type="submit" name="login">Login</button>

</form>

<div id="jsError" class="message"></div>
<div class="message"><?php echo $message; ?></div>

</div>

</body>
</html>